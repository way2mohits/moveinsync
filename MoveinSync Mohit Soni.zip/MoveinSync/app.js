const express=require('express');
const bodyParser=require("body-parser");
const mongoose=require('mongoose');
const app=express();




app.use(bodyParser.urlencoded({extended:true}));
app.use(express.static("public"));
app.set("view engine","ejs");
mongoose.connect("mongodb://localhost:27017/PhoneBook",{useNewUrlParser:true});
const itemSchema={
    name:{
        type:String,
        required:[true,"Please Enter Name Of Person"]
    },
    _mobile:{
        type:String,
        required:[true,"Please Enter Mobile number of Person"]
    },
    email:String,
    dob:String

};
const Item=mongoose.model("Item",itemSchema);
var element;
var resultItem=[];
app.get("/",function(req,res){
    Item.find(function(err,contacts){
        if(err){
            console.log(err);
        }
        else{
            res.render("index.ejs",{data:contacts});
        }
    }).sort({name:'ascending'});
})
app.get("/add.ejs",function(req,res){
    res.render("add.ejs",{success:''});
})
app.get("/remove.ejs",function(req,res){
    res.render("remove.ejs");
})
app.get("/searchByName.ejs",function(req,res){
    console.log(resultItem)
    res.render("searchByName",{data : resultItem});
    resultItem=[];

})
app.get("/searchByEmail.ejs",function(req,res){
    console.log(resultItem);
    res.render("searchByEmail",{data : resultItem});
    resultItem=[];
    
})

app.get("/searchByPhone.ejs",function(req,res){
    console.log(resultItem);
    res.render("searchByPhone",{data : resultItem});
    resultItem=[];
    
})
app.get("/update.ejs",function(req,res){
    res.render("update.ejs");
})
app.get("/delete.ejs",function(req,res){
    res.render("delete.ejs",{success:''});
})
app.post("/add.ejs",function(req,res){
    const newContact=new Item({
        name:req.body.name,
        _mobile:req.body.number,
        email:req.body.email,
        dob:req.body.DOB
    })
    newContact.save(function(err){
        if(err){
            console.log(err);
        }
        else{
            res.render("add.ejs",{success:"Succeffully Added!"});
        }
    });
})

app.post("/searchByPhone.ejs",function(req,res){
    element=req.body.number;
    Item.find({_mobile:element}, 'name _mobile email dob',function(err,result){
        resultItem=result;
    });
    res.redirect("/searchByPhone.ejs")
})

app.post("/searchByEmail.ejs",function(req,res){
    element=req.body.email;
    Item.find({'email':element}, 'name _mobile email dob',function(err,result){
        resultItem=result;
    }).sort({name:'ascending'});
    res.redirect("/searchByEmail.ejs")
})

app.post("/searchByName.ejs",function(req,res){
    element=req.body.name;
    Item.find({'name':{$regex:element}}, 'name _mobile email dob',function(err,result){
        resultItem=result;
    }).sort({name:'ascending'});
    res.redirect("/searchByName.ejs")
})
app.post("/update.ejs",function(req,res){
    Item.update({'_mobile':req.body.oldNumber},
        {
            name:req.body.name,
            _mobile:req.body.number,
            email:req.body.email,
            dob:req.body.dob
        })
    res.redirect("/update.ejs");
})
app.post("/delete.ejs",function(req,res){
    Item.deleteOne({_mobile:req.body.number},function(err){
        if(err){
            res.render("delete.ejs",{success:'Unsuccessfull'});
        }
        else{
            res.render("delete.ejs",{success:'Successfully Deleted'});
        }
    });
})
app.listen(3000,function(){
    console.log("Server Started");
})